//
//  SHRSegmentViewController.m
//  Assignment 4
//
//  Created by Shruti Chandrakantha on 10/20/14.
//  Copyright (c) 2014 Shruti Saligrama Chandrakantha LNU. All rights reserved.
//

#import "SHRSegmentViewController.h"
#define kProgressView 0
#define kTextView 1
#define kAlertView 2

@interface SHRSegmentViewController ()
@property (weak, nonatomic) IBOutlet UISegmentedControl *viewSelector;
@property (weak, nonatomic) IBOutlet UIView *progressSegmentView;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *indicator;
@property (weak, nonatomic) IBOutlet UIView *alertSegmentView;
@property (weak, nonatomic) IBOutlet UIView *textSegmentView;
@property (weak, nonatomic) IBOutlet UITextView *textView;

@end

@implementation SHRSegmentViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)switchState:(UISwitch *)sender
{
    UISwitch *activitySwitch = (UISwitch *)sender;
    if ([activitySwitch isOn])
        [self.indicator startAnimating];
    else
        [self.indicator stopAnimating];
}

- (IBAction)toggleView:(UISegmentedControl *)sender
{
    switch ([sender selectedSegmentIndex])
    {
        case kProgressView:
            [self showProgressView];
            break;
            
        case kTextView:
            [self showTextView];
            break;
        
        case kAlertView:
            [self showAlertView];
            break;
        
        default:
            break;
    
    }
}

- (IBAction)doneButtonPressed:(id)sender
{
    [self.textView resignFirstResponder];
}

- (IBAction)pressMeButtonPressed
{
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"This is an alert" message: @"Do you like iphone?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Yes",@"No", nil];
    [alert show]; 
}

- (void) showProgressView
{
    self.progressSegmentView.hidden = NO;
    self.textSegmentView.hidden = YES;
    self.alertSegmentView.hidden = YES;
    [self.textView resignFirstResponder];
    
}

- (void) showTextView
{
    self.textSegmentView.frame = self.progressSegmentView.frame;
    self.progressSegmentView.hidden = YES;
    self.textSegmentView.hidden = NO;
    self.alertSegmentView.hidden = YES;
    
}

- (void) showAlertView
{
    self.alertSegmentView.frame = self.progressSegmentView.frame;
    self.progressSegmentView.hidden = YES;
    self.textSegmentView.hidden = YES;
    self.alertSegmentView.hidden = NO;
    [self.textView resignFirstResponder];
    
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
