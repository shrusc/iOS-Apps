//
//  SHRFoodPickerViewController.h
//  Assignment 4
//
//  Created by Shruti Chandrakantha on 10/20/14.
//  Copyright (c) 2014 Shruti Saligrama Chandrakantha LNU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHRFoodPickerViewController : UIViewController
<UIPickerViewDelegate, UIPickerViewDataSource>

@end
