//
//  SHRWebViewController.m
//  Assignment 4
//
//  Created by Shruti Chandrakantha on 10/20/14.
//  Copyright (c) 2014 Shruti Saligrama Chandrakantha LNU. All rights reserved.
//

#import "SHRWebViewController.h"

@interface SHRWebViewController ()

@property (weak, nonatomic) IBOutlet UIWebView *webDisplayView;

@end

@implementation SHRWebViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UITapGestureRecognizer* tapBackground = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard:)];
    [tapBackground setNumberOfTapsRequired:1];
    [self.view addGestureRecognizer:tapBackground];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)doneTypingUrl:(id)sender {
    NSURL *url;
    if ([[sender text] hasPrefix:@"http://"] || [[sender text] hasPrefix:@"https://"])
        url = [NSURL URLWithString:[sender text]];
   else
        url = [NSURL URLWithString:[NSString stringWithFormat:@"http://%@",[sender text]]];

    if(url && url.scheme && url.host)
    {
        NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
        [self.webDisplayView loadRequest:requestObj];
    }
}

-(void) dismissKeyboard:(id)sender
{
    [self.view endEditing:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
