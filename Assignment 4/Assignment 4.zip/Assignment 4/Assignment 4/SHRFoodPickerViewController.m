//
//  SHRFoodPickerViewController.m
//  Assignment 4
//
//  Created by Shruti Chandrakantha on 10/20/14.
//  Copyright (c) 2014 Shruti Saligrama Chandrakantha LNU. All rights reserved.
//

#import "SHRFoodPickerViewController.h"

#define kCountryComponent 0
#define kFoodItemsComponent   1

@interface SHRFoodPickerViewController ()

@property (strong, nonatomic) NSDictionary *countryFoodItems;
@property (strong, nonatomic) NSArray *country;
@property (strong, nonatomic) NSArray *foodItems;
@property (weak, nonatomic) IBOutlet UIPickerView *countryFoodPicker;
@property (weak, nonatomic) IBOutlet UISlider *itemSlider;

@end

@implementation SHRFoodPickerViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSBundle *bundle = [NSBundle mainBundle];
    NSURL *plistURL = [bundle URLForResource:@"fooditems" withExtension:@"plist"];
    self.countryFoodItems = [NSDictionary dictionaryWithContentsOfURL:plistURL];
    NSArray *allCountries = [self.countryFoodItems allKeys];
    self.country = [allCountries sortedArrayUsingSelector:@selector(compare:)];;
    self.foodItems = [self.countryFoodItems[self.country[0]] sortedArrayUsingSelector:@selector(compare:)];
    
    //set the slider values
    self.itemSlider.minimumValue = 0;
    self.itemSlider.maximumValue = [self.foodItems count]-1;
    self.itemSlider.value = 0;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)sliderChanged:(UISlider *)sender {
    NSInteger rowValue=lroundf(sender.value);
    [self.countryFoodPicker reloadComponent:kFoodItemsComponent];
    [self.countryFoodPicker selectRow:rowValue inComponent:kFoodItemsComponent animated:YES];
    self.itemSlider.value = rowValue;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - Picker
#pragma mark Picker Data Source Methods
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 2;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView
numberOfRowsInComponent:(NSInteger)component
{
    if (component == kCountryComponent)
        return [self.country count];
    else
        return [self.foodItems count];
}

#pragma mark Picker Delegate Methods
- (NSString *)pickerView:(UIPickerView *)pickerView
             titleForRow:(NSInteger)row
            forComponent:(NSInteger)component
{
    if (component == kCountryComponent)
        return self.country[row];
    else
        return self.foodItems[row];
}

- (void)pickerView:(UIPickerView *)pickerView
      didSelectRow:(NSInteger)row
       inComponent:(NSInteger)component
{
    if (component == kCountryComponent)
    {
        NSString *selectedCountry = self.country[row];
        self.foodItems = [self.countryFoodItems[selectedCountry]
                          sortedArrayUsingSelector:@selector(compare:)];
        [self.countryFoodPicker reloadComponent:kFoodItemsComponent];
        [self.countryFoodPicker selectRow:0 inComponent:kFoodItemsComponent animated:YES];
        
        //set the slider values
        self.itemSlider.minimumValue = 0;
        self.itemSlider.maximumValue = [self.foodItems count]-1;
        self.itemSlider.value = 0;

    }
    if (component == kFoodItemsComponent)
    {
        self.itemSlider.value = row;
    }
    
}

@end
