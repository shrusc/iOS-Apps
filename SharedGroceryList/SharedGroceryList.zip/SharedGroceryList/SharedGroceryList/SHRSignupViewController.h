//
//  SHRSignupViewController.h
//  SharedGroceryList
//
//  Created by Shruti Chandrakantha on 11/28/14.
//  Copyright (c) 2014 Shruti Saligrama Chandrakantha LNU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHRSignupViewController : UIViewController <UITextFieldDelegate>


@end
