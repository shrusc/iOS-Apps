//
//  SHRListDetailViewController.h
//  SharedGroceryList
//
//  Created by Shruti Chandrakantha on 11/26/14.
//  Copyright (c) 2014 Shruti Saligrama Chandrakantha LNU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHRListDetailViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
@property NSString* listName;
@end
