//
//  SHRDetailViewController.h
//  Assignment 5
//
//  Created by Shruti Chandrakantha on 11/5/14.
//  Copyright (c) 2014 Shruti Saligrama Chandrakantha LNU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHRDetailViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>

@property NSNumber* lecturerId;

@end
