//
//  SHRPostDataViewController.h
//  Assignment 5
//
//  Created by Shruti Chandrakantha on 11/5/14.
//  Copyright (c) 2014 Shruti Saligrama Chandrakantha LNU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHRPostDataViewController : UIViewController <NSURLSessionDelegate>

@property NSNumber* lecturerId;

@end
