//
//  main.m
//  Assignment2
//
//  Created by Shruti Chandrakantha on 8/29/14.
//  Copyright (c) 2014 Shruti Saligrama Chandrakantha LNU. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSString+PhoneNumberMethods.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        /*PhoneNumber* number;
        number=[[PhoneNumber alloc] initType:@"fgdfysi" initNumber:@"619-594-6191"];
        //[@"619 594 6191" phoneFormat];
       // [@"619 5946191" phoneFormat];
        //[@"619-594-6191" phoneFormat];
        NSLog(@"type %@",number.phType);
         NSLog(@"number %@",number.phNumber);
       // BOOL ans;
        NSString* des;
        des=[number description];
        NSLog(@"ans %@",des);*/
        
    }
    return 0;
}

